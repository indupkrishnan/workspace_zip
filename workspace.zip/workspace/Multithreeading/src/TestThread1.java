
public class TestThread1 implements Runnable{
//import java.io.Serializable;
//public class TestThread1 extends Object implements Runnable,Serializable{


		public void run(){
			//for(int i=0;i<=3;i++){
				//System.out.println(i);
			System.out.println(Thread.currentThread().getName());
			for(int i=0;i<5;i++){
				try{
					Thread.sleep(1000);
				}
				catch(InterruptedException e){
					e.printStackTrace();
				}
				System.out.println(i+" Number of time");
				}
			
			}
				//System.out.println("in run method");
			//}
			
	
		public static void main(String[] args)throws InterruptedException {
			TestThread1 t=new TestThread1();
			Thread tt=new Thread(t);
			Thread t1=new Thread(new TestThread1());
			
			tt.setName("ttThread");
			
			t1.setName("t1Thread");
			tt.start();
			tt.join();
			t1.start();
			//tt.start();
		}
	}
