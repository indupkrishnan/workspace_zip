


public class SorryException extends RuntimeException{
String msg;
SorryException(){

}


public SorryException(String msg){
super();
this.msg=msg;

}


public String getMessage(){
	return msg;
}
}