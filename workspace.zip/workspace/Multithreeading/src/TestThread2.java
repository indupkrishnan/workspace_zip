



class one extends Thread{

	public void run(){

		System.out.println(Thread.currentThread().getName());
		for(int i=0;i<5;i++){
			try{
				Thread.sleep(1000);
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
			System.out.println("first "+i);
		}
		System.out.println("finished first");}

	}
	class two extends Thread{

		public void run(){

			System.out.println(Thread.currentThread().getName());
			for(int i=0;i<5;i++){
				try{
					Thread.sleep(600);
				}
				catch(InterruptedException e){
					e.printStackTrace();
				}
				System.out.println("second "+i);
			}
			System.out.println("finished second");}

		}

		public class TestThread2{
			public static void main(String[] args) {
				one t=new one();
				two t1=new two();

				t.setName("ttThread");
				t1.setName("t1Thread");
				t.start();
				t1.start();
				//tt.start();
			}
		}


