
class even extends Thread{

	public void run(){

		System.out.println(Thread.currentThread().getName());
		for(int i=0;i<20;i++){
			if(i%2==0){
				System.out.println("even"+i);
			}
			try{
				Thread.sleep(1000);
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
			System.out.println("first "+i);
		}
		System.out.println("finished even");}

	}
	class odd extends Thread{

		public void run(){

			System.out.println(Thread.currentThread().getName());
			for(int i=0;i<20;i++){
				if(i%2!=0){
					System.out.println("odd"+i);
				}
				//try{
				//	Thread.sleep(1000);
				//}
				//catch(InterruptedException e){
				//	e.printStackTrace();
				//}
				//System.out.println("second "+i);
			}
			System.out.println("finished odd");}

		}

		public class oddeven{
			public static void main(String[] args) {
				even t=new even();
				odd t1=new odd();

				t.setName("ttThread");
				t1.setName("t1Thread");
				t.start();
				t1.start();
				//tt.start();
			}
		}



