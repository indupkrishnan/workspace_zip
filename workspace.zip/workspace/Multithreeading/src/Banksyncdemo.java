class customer{
	int amt=0;
	int flag=0;

	public synchronized int withdraw(int amt){
		System.out.println(Thread.currentThread().getName()+" is going to withdraw");
		if(flag==0){
			try{
				System.out.println("Sorry..your acount has zero balance");
				wait();
			}
			catch(Exception e){}
			if(amt>this.amt){
				throw new SorryException("OOPS...NO SUFFICIENT BALANCE TO WITHDRAW..");
			}
			this.amt=this.amt-amt;
			System.out.println("withdraw completed.......");
			

		}
		return amt;
	}

//****************************************************************************************************


public synchronized void deposit(int amt){
	System.out.println(Thread.currentThread().getName()+" is going to deposit");
	
		this.amt=this.amt+amt;
		System.out.println(" after deposit your amount remaining is "+amt);
		notifyAll();
		flag=1;
		
	}
}

//*******************************************************************************************************
public class Banksyncdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
final customer c=new customer();
Thread t1=new Thread(){
	public void run(){
		c.withdraw(11000);
		//c.withdraw(1000);
		System.out.println(" after withdrawal balance amount is "+c.amt);
				}
		};
Thread t2=new Thread(){
	public void run(){
		c.deposit(4000);
		c.deposit(6000);
		
	}
};
t1.setName("ram");
t2.setName("radha");
t1.start();
t2.start();
}

}
