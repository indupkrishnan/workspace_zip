class Threadone extends Thread
public class syncblock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
