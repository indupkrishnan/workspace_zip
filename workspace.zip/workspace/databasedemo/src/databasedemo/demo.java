package databasedemo;
import java.sql.*;
public class demo {
	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost:3306/dbdemo";
		String username="root";
		String password="pranamam@NSS15";
		
		String sql1="create table emp(emp_id smallint not null primary key,emp_name varchar(30));";
		String sql2="insert into emp values('1','indu');";
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection(url,username,password);
Statement st=con.createStatement();
//st.executeUpdate(sql1);
//System.out.println("TABLE CREATED");
st.executeUpdate(sql2);
System.out.println("vaues inserted");
st.close();
con.close();
	}

}
