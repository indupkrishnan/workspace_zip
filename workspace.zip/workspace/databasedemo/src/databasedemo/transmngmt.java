package databasedemo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.SQLSyntaxErrorException;

public class transmngmt {

public static void main(String[] args)throws Exception {
// TODO Auto-generated method stub
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
String url="jdbc:mysql://localhost:3306/dbdemo";
String username="root";
String password="pranamam@NSS15";
try{
Class.forName("com.mysql.cj.jdbc.Driver");
con=DriverManager.getConnection(url,username,password);

DatabaseMetaData metaData=con.getMetaData();
Statement st=con.createStatement();
con.setAutoCommit(false);
String query="insert into emp values emp_id=?,emp_name=?";
ps=con.prepareStatement(query);
ps.setString(2, "subin");
ps.setInt(1, 3);
ps.executeUpdate();
System.out.println("successful.......");
}
catch(SQLException e){
	e.printStackTrace();
}
try{
	if(con!=null)
		con.rollback();
}catch(SQLException e){
	e.printStackTrace();
}
finally{
	try{
		if(rs!=null)
			rs.close();
		if(ps!=null)
			ps.close();
		if(con!=null)
			con.close();
		
	}
	catch(SQLException e){
		e.printStackTrace();
	}
}

}

}
