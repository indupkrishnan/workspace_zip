package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.Book;

public class BookDao {
public void saveBook(Book book)throws ClassNotFoundException{
	Connection con = null;
	PreparedStatement pre = null;
	try{
	String url = "jdbc:mysql://localhost:3306/userbook1";
	String user = "root";
	String password = "pranamam@NSS15";
	
	
	//loading drivers
	Class.forName("com.mysql.cj.jdbc.Driver");
	//creating connection
	con = DriverManager.getConnection(url, user, password);
	String query="insert into userreg2 values(?,?,?)";
    PreparedStatement ps=con.prepareStatement(query);
	ps.setInt(1, book.getId());
	ps.setString(2, book.getName());
	ps.setInt(3, book.getPrice());
	ps.executeUpdate();
//con.commit();
	} catch (SQLException e) {
	e.printStackTrace();
}
	
}




public List<Book>getAllBook() throws ClassNotFoundException, SQLException{
	Connection con = null;
	//PreparedStatement pre = null;
	
	String url = "jdbc:mysql://localhost:3306/userbook1";
	String user = "root";
	String password = "pranamam@NSS15";
	
	
	//loading drivers
	Class.forName("com.mysql.cj.jdbc.Driver");
	//creating connection
	con = DriverManager.getConnection(url, user, password);
	String query3="select * from userreg2 ";
    Statement st=con.createStatement();
    ResultSet rs=st.executeQuery(query3);
    List<Book> li =new ArrayList<Book>();
    while(rs.next()){
    	
    	
    	Book b=new Book();
    	b.setId(rs.getInt(1));
    	b.setName(rs.getString(2));
    	b.setPrice(3);
    	li.add(b);
    }
    System.out.println(li);
    return li;
//con.commit();
   
	
	
	
}
}
