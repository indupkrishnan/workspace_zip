package wrapperclassquest;

class wrap1 {
public static void main(String arg[]) { 
Integer x = 1000;
long y = 1000;
 Integer z = 1000;
System.out.println(x==y);
System.out.println(x==z);
System.out.println(x.equals(z));
}
}
 