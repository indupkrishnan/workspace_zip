package userdefinedexception;

public class Mainer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
validate v=new validate();
v.validate(89);
	}

}
