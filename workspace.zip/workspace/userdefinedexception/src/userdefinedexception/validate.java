package userdefinedexception;
import java.util.*;
public class validate {
static void validate(int age){
	if (age>18){
		throw new NameException("your age is greater than defined age limit..... ");
	}
}
}
