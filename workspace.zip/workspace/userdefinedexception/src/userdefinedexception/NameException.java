package userdefinedexception;

public class NameException extends RuntimeException{
String msg;
NameException(){

}


public NameException(String msg){
super();
this.msg=msg;

}


public String getMessage(){
	return msg;
}
}