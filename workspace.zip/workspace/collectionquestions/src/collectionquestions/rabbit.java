package collectionquestions;


import java.util.*;
public class rabbit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		System.out.println("Enter the character");
		char c=sc.next().charAt(0);
		StringBuffer sb=new StringBuffer(s);
		
		sb.reverse();
		for(int i=1;i<sb.length();i=i+2){
		sb.insert(i,c);
		}
		System.out.println(sb);
		
	}

}
