package collectionquestions;

import java.util.*;
public class california {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string:");
		String s=sc.next();
		System.out.println("Enter the n value:");
		int n=sc.nextInt();
		String s1=s.substring(0,n);
		System.out.println(s1);
		//System.out.println(s.length()-n);
		String s2=s.substring(s.length()-n,s.length());
		System.out.println(s2);
		String s3=s1.concat(s2);
		System.out.println(s3);
	
	}
}