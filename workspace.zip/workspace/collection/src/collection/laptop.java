package collection;
import java.io.Serializable;
public class laptop implements Serializable {
private String company;
private String HD;
private String processor;
public laptop(String company, String hD,String processor) {
	super();
	this.company = company;
	HD = hD;
	this.processor = processor;
}
@Override
public String toString() {
	return "laptop [company=" + company + ", HD=" + HD + ", processor=" + processor + ", getClass()=" + getClass()
			+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}


}
