
package collection;
import java.io.FileReader;
import java.io.*;
public class filewriter {
public static void main(String[] args)throws IOException {
	try {
		FileWriter writer=new FileWriter("D:frfile.txt",true);
		
		
		
		writer.write("neethu");
		writer.write("\n\n");
		writer.write("subin");
		writer.write("koooi...");
		writer.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
