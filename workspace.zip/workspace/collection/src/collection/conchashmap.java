
package collection;

import java.util.concurrent.*; 
import java.security.KeyStore.Entry;
import java.util.*;
import java.util.LinkedHashSet;

public class conchashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ConcurrentHashMap <Integer,String>  hm=new ConcurrentHashMap<Integer,String>();
	hm.put(1,"neethu");
	hm.put(2,"indu");
	hm.put(3,"subin");
	
	System.out.println(hm);
	String value=hm.putIfAbsent(4, "4 value");
	System.out.println(value);
	System.out.println(hm);
	
	
	String value1=hm.getOrDefault(4, "4 value");
	System.out.println(value1);
	System.out.println(hm);
	
	//Set<Entry<Integer,String>> e=hm.entrySet();
	//System.out.println(e);
	
	//****************FOR LOOP*************************************
	for(Map.Entry me:hm.entrySet()){
		System.out.println("key "+me.getKey()+"  value "+me.getValue());
	}

	
	//****************WHILE LOOP******************************************
Iterator itr=hm.entrySet().iterator();
while(itr.hasNext()){
	Map.Entry me1=(Map.Entry)itr.next();
	System.out.println("key "+me1.getKey()+"  value "+me1.getValue());
}
	}

}


