package collection;

import java.util.Comparator;

public class student1 {
	public int id;
	public String name;
	public String lname;
	public student1(int id,String name,String lname){
		this.id=id;
		this.name=name;
		this.lname=lname;
	}
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getLname() {
		return lname;
	}
	




//*********************************************************************

//public static Comparator<student1>studentnameComparator=new Comparator<student1>(){
	//public int compare(student1 s1,student2 s2){
		//String studentname1=s1.getstudentname().toUpperCase();

@Override
	public String toString() {
		return "student1 [id=" + id + ", name=" + name + ", lname=" + lname + "]";
	}





public static Comparator<student1> studentidcomparator=new Comparator<student1>(){
	public int compare(student1 s1,student1 s2){
		int i1=s1.getId();
		int i2=s1.getId();
		return  i2-i1;
	}
};
}
