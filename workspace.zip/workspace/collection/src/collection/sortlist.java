package collection;

import java.util.ArrayList;
import java.util.Collections;

public class sortlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList <String>s1=new ArrayList<String>();
s1.add("Renu");
s1.add("Amam");
s1.add("123");
s1.add("12");
s1.add("Saathi");
s1.add("SIathi");
s1.add("Balu");
s1.add("zAch");
s1.add("indu");
Collections.sort(s1);
System.out.println(s1);

	}

}
