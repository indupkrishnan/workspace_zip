package collection;
import java.io.*;
import java.util.*;
public class nobeldictionary {
private Map <String,TreeSet <String>> dictionary;

public 
}
