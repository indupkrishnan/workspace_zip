package collection;
import java.io.FileReader;
import java.io.*;
public class testreader {
public static void main(String[] args)throws IOException {
	try {
		FileReader fr=new FileReader("D:frfile.txt");
		
		int c;
		while((c=fr.read())!=-1){
			System.out.print((char)c);
		}
		fr.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
