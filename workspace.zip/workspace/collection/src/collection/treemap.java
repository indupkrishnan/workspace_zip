
package collection;
import java.security.KeyStore.Entry;
import java.util.*;
import java.util.LinkedHashSet;

public class treemap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	TreeMap <Integer,String>  tm=new TreeMap<Integer,String>();
	tm.put(5,"neethu");
	tm.put(2,"indu");
	tm.put(3,"subin");
	tm.put(4,"appu");
	//tm.put(4,null);
	//tm.put(null,null);
	//tm.put(null,"4");
	System.out.println(tm);
	String value=tm.putIfAbsent(4, "4 value");
	System.out.println(value);
	System.out.println(tm);
	
	
	String value1=tm.getOrDefault(4, "4 value");
	System.out.println(value1);
	System.out.println(tm);
	
	//Set<Entry<Integer,String>> e=hm.entrySet();
	//System.out.println(e);
	
	//****************FOR LOOP*************************************
	System.out.println("************************FOR LOOP***********************************");
	for(Map.Entry me:tm.entrySet()){
		System.out.println("key "+me.getKey()+"  value "+me.getValue());
	}

	
	//****************WHILE LOOP******************************************
	System.out.println("************************WHILE LOOP***********************************");
Iterator itr=tm.entrySet().iterator();
while(itr.hasNext()){
	Map.Entry me1=(Map.Entry)itr.next();
	System.out.println("key "+me1.getKey()+"  value "+me1.getValue());
}
//************************COVERTED TO SET***********************************
System.out.println("************************COVERTED TO SET***********************************");
Set set=tm.entrySet();
Iterator itr1=set.iterator();
while(itr1.hasNext()){
	Map.Entry me11=(Map.Entry)itr1.next();
	System.out.println("key "+me11.getKey()+"  value "+me11.getValue());
}

	}

}
