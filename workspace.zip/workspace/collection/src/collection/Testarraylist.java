package collection;

import java.util.ArrayList;

public class Testarraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> li=new ArrayList<String>();
li.add("neethu");
li.add("indu");
li.add("subin");
System.out.println(li);

ArrayList l1=new ArrayList();
//l1.add("meena");
//l1.add(23);
//l1.add("indu");

li.addAll(l1);

System.out.println(li);
//l1.remove(2);
l1.add(1,13);
System.out.println(l1);
	}

}
