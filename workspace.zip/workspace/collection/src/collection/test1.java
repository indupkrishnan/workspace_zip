
package collection;
import java.lang.*;
import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> l1=new ArrayList<String>();
l1.add("neethu");
l1.add("indu");
l1.add("subin");
l1.add(null);
l1.add(null);
System.out.println(l1);

ArrayList l2=new ArrayList();
l2.addAll(l1);
System.out.println("l2 before adding"+l2);
l2.add(2,"A+");
l2.add(78);
l2.add(789);
System.out.println("l2 after adding"+l2);
System.out.println(l2.subList(1,3));
System.out.println("*********");
l2.remove("789");
System.out.println(l2);
System.out.println("*********");
l1.remove("indu");
System.out.println(l1);
l2.removeAll(l1);
System.out.println(l2);

if(l2.contains(78)){
	System.out.println("value exists.....");
}
Object ob[]=l2.toArray();
for(Object o:ob){
	System.out.println(o);
}


if(l1.isEmpty()){System.out.println("it is empty");

}
else{System.out.println("not empty");
/*
List s= Arrays.asList(3,"fty");
System.out.println(s);
*/
Iterator it=l1.iterator();
while(it.hasNext()){
	System.out.println(it.next());
}
}
	}
}

