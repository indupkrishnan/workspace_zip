
package collection;
import java.util.*;
import java.lang.*;

public class hall22 implements Comparable<hall22>{
private String name;
private double costperday;
private int capacity;

public hall22(String name,double costperday,int capacity){
	this.name=name;
	this.costperday=costperday;
	this.capacity=capacity;
	
	}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public double getCostperday() {
	return costperday;
}

public void setCostperday(double costperday) {
	this.costperday = costperday;
}

public int getCapacity() {
	return capacity;
}

public void setCapacity(int capacity) {
	this.capacity = capacity;
}

@Override
public String toString() {
	return "hall [name=" + name + ", costperday=" + costperday + ", capacity=" + capacity + "]";
}
public int compareTo(hall22 ob){
	double comparecost=((hall22)ob).getCostperday();
	return (int)(comparecost-this.costperday);
}
}



