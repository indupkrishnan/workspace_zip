package collection;

public class student {
int id;
String name;
}
