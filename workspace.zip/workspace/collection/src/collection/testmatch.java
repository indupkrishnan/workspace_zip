package collection;
import java.util.*;
public class testmatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner sc=new Scanner(System.in);
		//System.out.println(" the first string");
		//System.out.println(" the second string");
		String s1="12-(134-7539";
		String s2="hi-here-you.";
		getvalues(s1,s2);
	}

		public static void getvalues(String s1,String s2){
		ArrayList  a1=new ArrayList();
		for(int i=0;i<s1.length();i++)
		{
			if(s1.charAt(i)=='-')
			{a1.add(i);
			}
		}
		
		ArrayList a2=new ArrayList();
		for(int i=0;i<s2.length();i++)
		{
			if(s2.charAt(i)=='-')
			{a2.add(i);
			}
		}
				System.out.println(a1);
				System.out.println(a2);
				if(a1.equals(a2)){
			System.out.println("true");
			}
			else{System.out.println("false");
			}
	}
	
}


