
package collection;
import java.io.FileReader;
import java.io.*;
public class brreader {
public static void main(String[] args)throws IOException {
	try {
		FileReader fr=new FileReader("D:frfile.txt");
		BufferedReader br=new BufferedReader(fr);
		String line;
		while((line=br.readLine())!=null){
			System.out.println(line);
		}
		fr.close();
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
