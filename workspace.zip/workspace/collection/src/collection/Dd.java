package collection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Dd {
public static void main(String[] args) throws ParseException {
String s1="40/01/2006";
getvalues(s1);
}
public static void getvalues(String s1) throws ParseException {
//if(s1.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}"))
//{

//sdf.setLenient(false);

Date d1=new SimpleDateFormat("dd/MM/yyyy").parse(s1);
System.out.println(d1);
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
//String str3=sdf.format(d1);
String str3=d1.toString();
System.out.println(str3);
System.out.println(s1);
if(str3.equals(s1)){
System.out.println("1");

//System.out.println(-1);

}
else{
System.out.println("-1");
}
}
}
