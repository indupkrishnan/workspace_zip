
package collection;
import java.io.FileReader;
import java.io.*;
public class bufferedwriter {
public static void main(String[] args)throws IOException {
	try {
		FileWriter writer=new FileWriter("D:frfile.txt",true);
		BufferedWriter bw=new BufferedWriter(writer);
		bw.write("hellooo");
		bw.newLine();
		bw.write("hen");
		bw.newLine();
		bw.close();
	
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
