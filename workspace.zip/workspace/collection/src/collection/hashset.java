package collection;
import java.util.*;
import java.util.LinkedHashSet;

public class hashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	LinkedHashSet <String>  hs=new LinkedHashSet<String>();
	hs.add("neethu");
	hs.add("indu");
	hs.add("subin");
	hs.add(null);
	hs.add("neethu");
	hs.add("indu");
	hs.add("subin");
	System.out.println(hs);
	
	
	HashSet <String>  hs1=new HashSet<String>();
	hs1.add("neethu");
	hs1.add("indu");
	hs1.add("subin");
	hs1.add(null);
	hs1.add("neethu");
	hs1.add("indu");
	hs1.add("subin");
	System.out.println(hs1);
	
	TreeSet <String>  ts1=new TreeSet<String>();
	ts1.add("neethu");
	ts1.add("indu");
	ts1.add("subin");
	//ts1.add(null);
	ts1.add("neethu");
	ts1.add("indu");
	ts1.add("subin");

	
	System.out.println(ts1);

	}

}
