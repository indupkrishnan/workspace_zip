package collection;
import java.io.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Testserializablelaptop {


	static void serialize(laptop l)throws IOException{
		try{
	
	FileOutputStream fos=new FileOutputStream ("D:laptop.text");
	ObjectOutputStream oos=new  ObjectOutputStream(fos);
	oos.writeObject(l);
	oos.close();
	fos.close();
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		}
	
	
	static laptop deserialize()throws ClassNotFoundException{
		laptop l1=null;
		try{
	
	FileInputStream fos=new FileInputStream ("D:laptop.text");
	ObjectInputStream oos=new ObjectInputStream(fos);
	l1=(laptop)oos.readObject();
	oos.close();
	fos.close();
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		return l1;
		}

public static void main(String[] args)throws IOException,ClassNotFoundException{
	
	laptop l=new laptop("HP","1TB","32-bit");
	serialize(l);
	System.out.println("serialized.......");
	laptop l1=deserialize();
	System.out.println(l1);
	System.out.println("deserialized.......");
}
}