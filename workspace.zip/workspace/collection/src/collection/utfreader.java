
package collection;
import java.io.*;
public class utfreader {
public static void main(String[] args)throws IOException {
	try {
		FileInputStream fis=new FileInputStream("D:frfile.txt");
		InputStreamReader isr=new InputStreamReader(fis,"UTF-8");
		int character;
		while((character=isr.read())!=-1){
			System.out.print((char)character);
		}
		isr.close();
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
