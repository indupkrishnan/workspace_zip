package collection;

import java.util.ArrayList;
import java.util.Collections;

public class comparatorexample {
public static void main(String[] args) {
	ArrayList<student1>a1=new ArrayList<student1>();
	a1.add(new student1(43,"indu","p"));
	a1.add(new student1(24,"neethu","j"));
	a1.add(new student1(32,"subin","k"));
	Collections.sort(a1,student1.studentidcomparator);
	for(student1 st:a1){
		System.out.println(st);
	}
	
}
}
