package collection;



import java.util.ArrayList;
import java.util.Collections;

public class hallexample {
public static void main(String[] args) {
	ArrayList<hall>a1=new ArrayList<hall>();
	a1.add(new hall("indu",5000,7));
	a1.add(new hall("neethu",10000,4));
	a1.add(new hall("subin",7000,5));
	Collections.sort(a1,hall.hallcomp);
	for(hall st:a1){
		System.out.println(st);
	}
	
}
}
