package com.cognizant.training;
import java.util.Scanner;
public class Testmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		employee emp=new employee();
		acceptEmployeeDetails(emp);
		displayEmployeeDetails(emp);
	}

private static void acceptEmployeeDetails(employee emp){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter employeeid ");
	String empId=sc.nextLine();
	emp.setEmpId(empId);
	System.out.println("Enter employeename ");
	String empName=sc.nextLine();
	emp.setEmpName(empName);
	Address address=new Address();
	System.out.println("Enter employee address1 ");
	String address1=sc.nextLine();
	address.setAddress1(address1);
	System.out.println("Enter employee address2 ");
	String address2=sc.nextLine();
	address.setAddress2(address2);
	

	
	System.out.println("Enter employeecity ");
	String city=sc.nextLine();
	address.setCity(city);
	System.out.println("Enter employeepincode ");
	int pincode=sc.nextInt();
	address.setPincode(pincode);
	emp.setAddress(address);
}
private static void displayEmployeeDetails(employee emp){
	System.out.println("EmployeeId "+emp.getEmpId());
	System.out.println("Employeename "+emp.getEmpName());
	System.out.println("Employeeaddress1 "+emp.getAddress().getAddress1());
	System.out.println("Employeeaddress2 "+emp.getAddress().getAddress2());
	System.out.println("Employeecity "+emp.getAddress().getCity());
	System.out.println("Employeecitypincode "+emp.getAddress().getPincode());
	
}
}
