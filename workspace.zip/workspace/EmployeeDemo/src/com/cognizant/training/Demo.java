package com.cognizant.training;


class Object{
	Object(){System.out.println("object class constructor");}
}
public class Demo extends Object{

Demo(){
		System.out.println("demo class constructor");
	}
public class Test extends Demo{
	
	Test(){
		System.out.println("test class constructor");	
	}
	
}
}

