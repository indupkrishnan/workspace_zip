
package java8features;
import java.text.*;
import java.time.*;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.GregorianCalendar;


public class Basicdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
LocalDate ld=LocalDate.now();
System.out.println(ld.toString());
System.out.println(ld.getDayOfWeek());
System.out.println(ld.getDayOfMonth());
System.out.println(ld.getDayOfYear());
System.out.println("********************************************");
ZonedDateTime zdt=ZonedDateTime.now();
System.out.println(zdt);
LocalDate d1=zdt.toLocalDate();
System.out.println("current date: "+d1);
ZoneId zone=zdt.getZone();
System.out.println("zone info: "+zone.getId());
int dayofmonth=zdt.getDayOfMonth();
System.out.println("dayof month: "+dayofmonth);
Month mnth=zdt.getMonth();
System.out.println("Month: "+mnth.getValue());
System.out.println("********************************************");
System.out.println("today");
Date today=new Date();
DateFormat df=new SimpleDateFormat("dd/MM/yyyy");
System.out.println(df.format(today));


Calendar c=new GregorianCalendar();
System.out.println(c);


	}

}
