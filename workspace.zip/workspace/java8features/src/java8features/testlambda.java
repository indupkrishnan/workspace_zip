package java8features;
interface TestPi{
	//public double getpi();
	public int getSum(int x,int y);
}

//class Piclass implements TestPi{
	//public double getpi(){
	//	return 3.14;
	//}

	
//}
public class testlambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//TestPi p=()->3.142;
TestPi p3 =(x,y)->x+y;
System.out.println(p3.getSum(12, 8));
//System.out.println("pi value is "+p.getpi());
//TestPi pp=new Piclass();
//pp.getpi();
//System.out.println("pi value is "+pp.getpi());
	}

}
