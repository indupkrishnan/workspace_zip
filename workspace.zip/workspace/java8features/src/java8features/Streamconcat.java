package java8features;

import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

public class Streamconcat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//list1
List<String> alpha=Arrays.asList("A","B","C");
//list2
List<String> names=Arrays.asList("indu","neethu","subin");
Stream s1=alpha.stream();
//create 2 streams from the 2 lists and concatenating into one
Stream<String> opstream=Stream.concat(s1,names.stream());
opstream.forEach(str->System.out.print(str+" "));
System.out.println();


Stream<Integer> streamofnos=Stream.of(7,5,4,2,9,53,555);
System.out.println(streamofnos.filter(i->i>6).count());

	}

}
