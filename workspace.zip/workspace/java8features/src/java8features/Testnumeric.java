package java8features;

import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

public class  Testnumeric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
NumericTest isEven=(n)->(n%2)==0;
NumericTest isNegative=(n)->(n<0);
System.out.println(isEven.computeTest(5));
System.out.println(isEven.computeTest(-5));


	}

}
