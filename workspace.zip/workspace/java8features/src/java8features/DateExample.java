package java8features;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
public class DateExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Date today=new Date();
System.out.println("note the time includes the default time-zone "+today);
System.out.println("*****************************************");
DateFormat df=new SimpleDateFormat("dd/MM/yyyy");
DateFormat ddMMyyy = null;
System.out.println("formattedcdate is"+ddMMyyy.format(df));



	}

}
