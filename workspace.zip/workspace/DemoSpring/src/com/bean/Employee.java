package com.bean;

public class Employee extends Person{
int id;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
}
