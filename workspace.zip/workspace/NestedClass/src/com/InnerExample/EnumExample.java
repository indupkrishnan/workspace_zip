package com.InnerExample;


enum Directions{
	EAST,
	WEST,
	NORTH,
	SOUTH
}


public class EnumExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Directions dir=Directions.NORTH;
		if(dir==Directions.EAST){
			System.out.println("east");
		}
		else if(dir==Directions.WEST){
			System.out.println("west");
		}
		else if(dir==Directions.NORTH){
			System.out.println("north");
		}
		else {
			System.out.println("south");
		}
	
	//Directions dir=Directions.NORTH;
	//Iterator itr=dir.iterator();
	
	for(Directions d:Directions.values()){
		System.out.println("values "+d);
	}
	System.out.println(Directions.valueOf("SOUTH"));//get instance of string value
}}
