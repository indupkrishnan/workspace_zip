package com.InnerExample;

 interface Age{
 //static final int x=20;
 int x=20;
	public abstract void getAge();



//public Person implements Age{
//	public void getAge(){
		
	//}
	
 }
public class AnonymousDemo{
public static void main(String[] args) {
	Age oj=new Age(){
		public void getAge(){
		System.out.println("age is  "+x);	
		}
		
	};
	oj.getAge();
}
}